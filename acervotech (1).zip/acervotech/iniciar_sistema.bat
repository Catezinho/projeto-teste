@echo off
echo Iniciando o Servidor do Acervo Tech no caminho correto...
cd /d "C:\Users\eliva\OneDrive\Imagens\Documentos\acervotech\back-end"
uvicorn main:app --reload
pause