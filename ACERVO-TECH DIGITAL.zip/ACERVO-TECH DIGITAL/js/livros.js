function carregarTabelaLivros() {
    const tbody = document.getElementById('tabelaLivros');
    tbody.innerHTML = '';
    livros.forEach(l => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${l.id}</td>
            <td>${l.titulo}</td>
            <td>${l.autor}</td>
            <td>${l.isbn}</td>
            <td>${l.categoria}</td>
            <td>${l.exemplares}</td>
            <td>${l.disponiveis}</td>
            <td class="acoes">
                <button class="btn-editar" onclick="editarLivro(${l.id})">Editar</button>
                <button class="btn-excluir" onclick="excluirLivro(${l.id})">Excluir</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function abrirFormLivro() {
    document.getElementById('formLivroContainer').style.display = 'block';
    document.getElementById('formLivroTitulo').textContent = 'Cadastrar Livro';
    document.getElementById('formLivro').reset();
    document.getElementById('livroId').value = '';
}

function fecharFormLivro() {
    document.getElementById('formLivroContainer').style.display = 'none';
}

document.getElementById('formLivro').addEventListener('submit', function(e) {
    e.preventDefault();
    const id = document.getElementById('livroId').value;
    const titulo = document.getElementById('titulo').value.trim();
    const autor = document.getElementById('autor').value.trim();
    const isbn = document.getElementById('isbn').value.trim();
    const categoria = document.getElementById('categoria').value.trim();
    const exemplares = parseInt(document.getElementById('exemplares').value);

    if (id) {
        const livro = livros.find(l => l.id == id);
        if (livro) {
            livro.titulo = titulo;
            livro.autor = autor;
            livro.isbn = isbn;
            livro.categoria = categoria;
            livro.exemplares = exemplares;
            livro.disponiveis = Math.min(livro.disponiveis, exemplares);
        }
    } else {
        livros.push({
            id: proximoId(livros),
            titulo, autor, isbn, categoria,
            exemplares,
            disponiveis: exemplares
        });
    }
    fecharFormLivro();
    carregarTabelaLivros();
});

function editarLivro(id) {
    const livro = livros.find(l => l.id === id);
    if (!livro) return;
    document.getElementById('livroId').value = livro.id;
    document.getElementById('titulo').value = livro.titulo;
    document.getElementById('autor').value = livro.autor;
    document.getElementById('isbn').value = livro.isbn;
    document.getElementById('categoria').value = livro.categoria;
    document.getElementById('exemplares').value = livro.exemplares;
    document.getElementById('formLivroTitulo').textContent = 'Editar Livro';
    document.getElementById('formLivroContainer').style.display = 'block';
}

function excluirLivro(id) {
    if (confirm('Deseja excluir este livro?')) {
        livros = livros.filter(l => l.id !== id);
        carregarTabelaLivros();
    }
}